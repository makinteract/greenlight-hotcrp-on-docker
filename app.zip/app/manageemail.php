<?php
// manageemail.php -- HotCRP delegation page
// Copyright (c) 2006-2025 Eddie Kohler; see LICENSE.

include("index.php");
