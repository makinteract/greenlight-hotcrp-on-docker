<?php
// authorize.php -- HotCRP delegation page
// Copyright (c) 2006-2024 Eddie Kohler; see LICENSE.

include("index.php");
