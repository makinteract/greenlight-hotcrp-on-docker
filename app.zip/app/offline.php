<?php
// offline.php -- HotCRP delegation page
// Copyright (c) 2006-2022 Eddie Kohler; see LICENSE.

include("index.php");
