<?php
// test/cdb-options.php -- HotCRP conference options for test databases

global $Opt;
$Opt["dbName"] = "hotcrp_testdb_cdb";
$Opt["dbUser"] = "hotcrp_testdb";
$Opt["dbPassword"] = "m5LuaN23j26g";
$Opt["shortName"] = "Testconf I";
$Opt["longName"] = "Test Conference I";
$Opt["contactName"] = "Eddie Kohler";
$Opt["contactEmail"] = "ekohler@hotcrp.lcdf.org";
$Opt["sendEmail"] = false;
$Opt["debugShowSensitiveEmail"] = true;
$Opt["emailFrom"] = "you@example.com";
